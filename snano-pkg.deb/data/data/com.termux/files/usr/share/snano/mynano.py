import curses
import sys
import os

VERSION = "v1.0.0"

def main(stdscr):
    # Setup warna
    curses.start_color()
    # Pasangan warna 1: Tulisan Hitam, Background Putih (buat bar atas/bawah)
    curses.init_pair(1, curses.COLOR_BLACK, curses.COLOR_WHITE)
    
    stdscr.keypad(True)
    
    # Ambil nama file dari argumen
    filename = sys.argv[1] if len(sys.argv) > 1 else "New File"
    
    # Load isi file
    if os.path.exists(filename):
        with open(filename, 'r') as f:
            lines = f.read().splitlines()
            if not lines: lines = [""]
    else:
        lines = [""]

    while True:
        stdscr.clear()
        height, width = stdscr.getmaxyx()

        # --- 1. TASKBAR ATAS (HEADER) ---
        # Bikin background putih buat baris paling atas
        stdscr.attron(curses.color_pair(1))
        stdscr.addstr(0, 0, " " * width) # Isi spasi biar putih semua
        
        # Nama Tools (Pojok Kiri)
        stdscr.addstr(0, 0, " GNU snano ")
        
        # Versi (Tengah)
        ver_text = f"Version {VERSION}"
        stdscr.addstr(0, (width // 2) - (len(ver_text) // 2), ver_text)
        
        # Nama File (Pojok Kanan)
        file_display = f"File: {filename} "
        if len(file_display) < width // 3: # Biar gak tabrakan sama tengah
            stdscr.addstr(0, width - len(file_display), file_display)
        
        stdscr.attroff(curses.color_pair(1))

        # --- 2. AREA TEKS ---
        for i, line in enumerate(lines[:height-3]):
            # i+1 karena baris 0 udah dipake Header
            stdscr.addstr(i + 1, 0, line[:width-1])

        # --- 3. MENU BAWAH ---
        menu = " ^X Exit | ^S Save "
        stdscr.addstr(height-1, 0, menu[:width-1], curses.A_REVERSE)

        stdscr.refresh()
        
        try:
            key = stdscr.getch()
        except KeyboardInterrupt:
            continue

        if key == 24: # CTRL+X
            break
        elif key == 19: # CTRL+S
            # Save logic (hanya kalau bukan "New File")
            save_name = filename if filename != "New File" else "saved_file.txt"
            with open(save_name, 'w') as f:
                f.write("\n".join(lines))
        elif key == 10: # Enter
            lines.append("")
        elif key in (curses.KEY_BACKSPACE, 127, 8): # Backspace
            if lines[-1]:
                lines[-1] = lines[-1][:-1]
            elif len(lines) > 1:
                lines.pop()
        elif key < 256:
            lines[-1] += chr(key)

curses.wrapper(main)

